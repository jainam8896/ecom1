import User from "../../models/User.js";
import bcrypt from "bcrypt";
import jwt from "jsonwebtoken";

//User login
const userLogin = async (req, res) => {
  try {
    const { email, password } = req.body;
    if (email && password) {
      const user = await User.findOne({ email: email });
      if (user != null) {
        const match = await bcrypt.compare(password, user.password);
        if (user.email === email && match) {

          //Genrate Token
          const user = await User.findOne({ email: email });
          const token = jwt.sign({ userID: user._id },process.env.JWT_SECRET_KEY,{ expiresIn: "5d" });

          res.send({status: "success",message: "Login Success",token: token});
        } else {
          res.send({status: "failed",message: "Email or Password is Invalid"});
        }
      } else {
        res.send({ status: "failed", message: "User Not Register" });
      }
    } else {
      res.send({ status: "failed", message: "All Filds Are require" });
    }
  } catch (error) {
    res.send({ status: "failed", message: "Unable to login" });
  }
};

export default userLogin;