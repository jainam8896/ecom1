import Category from "../../models/Category.js";

//Create user
const createCategory = async (req, res) => {
  const { name } = req.body;
  const category = await Category.findOne({ name: name });
  if (category) {
    res.send({ status: "failed", message: "Category Already Exists.....Please Enter Different Category" });
  } else {
    if (name) {
      try {
        const category = await Category.create(req.body);
        res.json(category);
      } catch (error) {
        res.json(error);
      }
    } else {
      res.send({ status: "failed", message: "All Field Are Required" });
    }
  }
};


export default createCategory;
