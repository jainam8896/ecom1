import express from 'express'
const route = express.Router()
import createCategory from '../controller/category/create.js'
import getCategory from '../controller/category/display.js'
import getCategoryRoot from '../controller/category/getcategoryById.js'
import deletcategory from '../controller/category/delete.js'
import updateCategory from '../controller/category/update.js'

route.post('/api/createcategory',createCategory)
route.get('/api/getcategory',getCategory)
route.get('/api/getcategory-root/:id',getCategoryRoot)
route.delete('/api/deletecategory/:id',deletcategory)
route.put('/api/updatecategory/:id',updateCategory)

export default route