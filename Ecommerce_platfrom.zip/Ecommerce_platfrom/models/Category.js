import  mongoose  from "mongoose";

const categorySchema = new mongoose.Schema({
    name:{
        type: String,
        required:true
    },
    parentId:{
        type:mongoose.Schema.Types.ObjectId,
        ref:'Category',
        default:null
    }
},{timestamps:true})

categorySchema.pre('find',function(){
    this.populate('parentId')
})
const Category = mongoose.model('Category',categorySchema)
export default Category